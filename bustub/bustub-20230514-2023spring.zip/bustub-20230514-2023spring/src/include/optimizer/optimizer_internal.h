#pragma once

namespace bustub {

// Note: You can define your optimizer helper functions here
void OptimizerHelperFunction();

}  // namespace bustub
