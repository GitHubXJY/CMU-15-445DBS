namespace bustub {

void OptimizerHelperFunction() {}

}  // namespace bustub
